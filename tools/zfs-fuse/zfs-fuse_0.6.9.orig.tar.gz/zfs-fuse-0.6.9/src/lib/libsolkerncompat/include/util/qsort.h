/* For the definition of qsort(3) */
#include_next <stdlib.h>
