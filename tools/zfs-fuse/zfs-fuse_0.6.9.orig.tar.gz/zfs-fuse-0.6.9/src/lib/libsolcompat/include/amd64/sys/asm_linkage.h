#ifndef __amd64
#define __amd64
#endif

#include <ia32/sys/asm_linkage.h>
