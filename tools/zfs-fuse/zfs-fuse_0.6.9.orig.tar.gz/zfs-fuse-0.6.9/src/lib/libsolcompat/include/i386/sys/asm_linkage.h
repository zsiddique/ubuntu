#ifndef __i386
#define __i386
#endif

#include <ia32/sys/asm_linkage.h>
