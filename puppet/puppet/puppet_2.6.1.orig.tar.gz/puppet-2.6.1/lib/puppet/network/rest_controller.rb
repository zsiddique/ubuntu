class Puppet::Network::RESTController # :nodoc:
end
