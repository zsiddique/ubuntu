class Puppet::Network::Client::Status < Puppet::Network::Client::ProxyClient
  self.mkmethods
end

