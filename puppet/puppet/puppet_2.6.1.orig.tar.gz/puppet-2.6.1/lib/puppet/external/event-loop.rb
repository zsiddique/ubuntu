require "puppet/external/event-loop/event-loop"
